// imports
const expect = require('chai').expect;
const response = require('../helpers/response.js');

const models = require('../../db/models');
const testConfig = require('../../setup.spec.js');
const constraints = require('../../constraints.js');

// globals
const { testNotification } = testConfig;
const NotificationTypes = constraints.NotificationTypes;

// test cases - name space
describe('controllers', function () {
  // stubs meta
  let stubsMetaArr = [];
  stubsMetaArr.push({ object: models.Notification, method: 'create', return: testNotification });
  stubsMetaArr.push({ object: models.Notification, method: 'updateNotification', return: testNotification });
  stubsMetaArr.push({ object: models.Notification, method: 'deleteNotification', return: testNotification });
  stubsMetaArr.push({ object: models.Notification, method: 'getAllForAppIdWithType', return: [testNotification] });

  // hooks setup
  testConfig.setupStubs(stubsMetaArr);
  const testControllerRequest = testConfig.getTestControllerRequest();

  // test space
  describe('notificationController', function () {
    it('list: should return notifications', function () {
      const resBody = response.successResponse('Notification List', [testNotification]);
      return testControllerRequest
        .get(`/api/notifications/apps/:id?type=${NotificationTypes.slackwebhook}`)
        .then(response => expect(response.body).to.deep.equal(resBody));
    });

    it('create: should create notification', function () {
      const resBody = response.successResponse('Notification Created', [testNotification]);
      return testControllerRequest
        .post(`/api/notifications/apps/:id?type=${NotificationTypes.slackwebhook}`)
        .send({ title: 'abc', params_json: { url: 'www.abc.def' } })
        .then(response => expect(response.body).to.deep.equal(resBody));
    });

    it('update: should update notification', function () {
      const resBody = response.successResponse('Notification Updated', [testNotification]);
      return testControllerRequest
        .put(`/api/notifications/apps/:id/notifications/:id?type=${NotificationTypes.slackwebhook}`)
        .send({ title: 'abc', params_json: { url: 'www.abc.def' } })
        .then(response => expect(response.body).to.deep.equal(resBody));
    });

    it('destroy: should delete notification', function () {
      const resBody = response.successResponse('Notification Deleted', [testNotification]);
      return testControllerRequest
        .delete('/api/notifications/apps/:id/notifications/:id')
        .then(response => expect(response.body).to.deep.equal(resBody));
    });
  });
});