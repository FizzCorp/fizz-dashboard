'use strict';

// imports
const utility = require('../helpers/utility.js');
const response = require('../helpers/response.js');
const validator = require('../../validators').notificationValidator;

const models = require('../../db/models');
const expressRouter = require('express').Router;

// globals
const router = expressRouter();
const commonMiddleWares = utility.commonMiddleWares;

// structs
const list = {
  performAndSend: (req, res, next) => {
    validator
      .list({ query: req.query, params: req.params, body: req.body })
      .then(validationRes => models.Notification.getAllForAppIdWithType(req.params.app_id, req.query.type))
      .then(notifications => res.send(response.successResponse('Notification List', notifications)))
      .catch(error => next(response.internalServerError(error)));
  }
};

const create = {
  performAndSend: (req, res, next) => {
    const createParams = {
      app_id: req.params.app_id,
      title: req.body.title,
      type: req.query.type,
      params_json: req.body.params_json
    };

    validator
      .create({ query: req.query, params: req.params, body: req.body })
      .then(validationRes => models.Notification.create(createParams))
      .then(createdNotification => res.send(response.successResponse('Notification Created', [createdNotification])))
      .catch(error => next(response.internalServerError(error)));
  }
};

const update = {
  performAndSend: (req, res, next) => {
    validator
      .update({ query: req.query, params: req.params, body: req.body })
      .then(validationRes => models.Notification.updateNotification(req.params.notification_id, req.body))
      .then(updatedNotification => res.send(response.successResponse('Notification Updated', [updatedNotification])))
      .catch(error => next(response.internalServerError(error)));
  }
};

const destroy = {
  performAndSend: (req, res, next) => {
    validator
      .destroy(req.params)
      .then(validationRes => models.Notification.deleteNotification(req.params.notification_id))
      .then(deletedNotification => res.send(response.successResponse('Notification Deleted', [deletedNotification])))
      .catch(error => next(response.internalServerError(error)));
  }
};

// entry point
function notification() {
  return {
    list: [
      list.performAndSend,
      commonMiddleWares.handleErrorsIfAny
    ],
    create: [
      create.performAndSend,
      commonMiddleWares.handleErrorsIfAny
    ],
    update: [
      update.performAndSend,
      commonMiddleWares.handleErrorsIfAny
    ],
    destroy: [
      destroy.performAndSend,
      commonMiddleWares.handleErrorsIfAny
    ]
  };
}

// route setup
const notificationController = notification();
router.get('/apps/:app_id', notificationController.list);// ?type=notification_type
router.post('/apps/:app_id', notificationController.create);// ?type=notification_type
router.put('/apps/:app_id/notifications/:notification_id', notificationController.update);// ?type=notification_type
router.delete('/apps/:app_id/notifications/:notification_id', notificationController.destroy);

// exports
module.exports = router;